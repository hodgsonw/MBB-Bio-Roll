
int print_usage (char *arg);
int print_usage_2d (char *arg);
int print_usage_est (char *arg);
int print_usage_div (char *arg);
int print_usage_est_2d (char *arg);
int print_usage_454 (char *arg);
