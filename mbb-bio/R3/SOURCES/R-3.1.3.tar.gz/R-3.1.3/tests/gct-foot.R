cat("Time used {gctorture()}:", proc.time() - .ptime, "\n")
