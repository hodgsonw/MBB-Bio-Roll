#ifndef HDEF_binarySearch2
#define HDEF_binarySearch2

#include "IncludeDefine.h"
int binarySearch2(uint x, uint y, uint *X, uint *Y, int N);

#endif
